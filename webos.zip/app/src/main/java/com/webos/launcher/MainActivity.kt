package com.webos.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val t = params.acceptTypes.firstOrNull { it.contains("/") } ?: "*/*"
                val i = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(t)
                    .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(i, 1)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            var result: Array<Uri>? = null
            if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) {
                    result = Array(clip.itemCount) { clip.getItemAt(it).uri }
                } else if (data.data != null) {
                    result = arrayOf(data.data!!)
                }
            }
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    private fun status(msg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.onApkStatus&&onApkStatus(" + JSONObject.quote(msg) + ")", null)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Home screen: ignore Back
    }

    inner class Bridge {
        @JavascriptInterface
        fun exitToDefaultLauncher() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface
        fun isInstalled(pkg: String): Boolean =
            packageManager.getLaunchIntentForPackage(pkg) != null

        @JavascriptInterface
        fun launchApp(pkg: String) {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
            runOnUiThread { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }

        @JavascriptInterface
        fun installApk(url: String) {
            if (!packageManager.canRequestPackageInstalls()) {
                runOnUiThread {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                status("Allow installs from WebOS, then tap Download again")
                return
            }
            status("Downloading...")
            Thread {
                try {
                    val dir = File(cacheDir, "apk")
                    dir.mkdirs()
                    val f = File(dir, "app.apk")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.instanceFollowRedirects = true
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    val head = ByteArray(2)
                    val n = f.inputStream().use { it.read(head) }
                    if (n < 2 || head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) {
                        status("That link is not an APK file")
                        return@Thread
                    }
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    val i = Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    runOnUiThread { startActivity(i) }
                    status("Download finished. Confirm the install.")
                } catch (e: Exception) {
                    status("Download failed")
                }
            }.start()
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
